
class Solver:

    # ax + b = c
    def calc(self, a, b, c):
        ax = c - b
        x = ax/a
        return x

