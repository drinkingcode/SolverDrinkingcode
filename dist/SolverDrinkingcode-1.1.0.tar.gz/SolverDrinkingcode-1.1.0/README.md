### SolverDrinkingcode
```
It's an example for uploading Python package into Python Package Index.

It will teach you how to upload Python package so that you can share with 
other people around the world.
```
